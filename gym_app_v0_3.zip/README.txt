GYM LOG v0.3
Mobiele PWA. Nieuw: oefeningen toevoegen, wijzigen en verwijderen per trainingsdag. Schema wordt lokaal opgeslagen.
Ook aanwezig: trainingsflow, set/reps invoer, vorige training, timer, PR's en weekoverzicht.
Host de map via HTTPS (bijv. GitHub Pages) en installeer via Chrome > Toevoegen aan startscherm/Installeren.
